//Initialiserar karusellen för gallerian
//$('.carousel').carousel({interval: 2000})